
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main () {
    int x = 5;
    double y;
    y = x + 6.60;
    printf("%f\n", y);
}